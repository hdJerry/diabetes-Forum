
<html>
<head>
<title>Post|Testimonies</title>
</head>
<body>
<?php
$host = "localhost";
$user = "root";
$password = "";
$conn =  mysql_connect($host,$user,$password);
if(!$conn){
	die("Could not connect to database".mysql_error());
}
echo "Connection successful<br/>";
mysql_select_db("POST");
$sql = "CREATE TABLE posts(
            post_id INT(6) NOT NULL AUTO_INCREMENT,
            content VARCHAR(255) NOT NULL,
            username VARCHAR(25) NOT NULL,
           PRIMARY KEY(post_id)
)";
$result = mysql_query($sql,$conn);
if(!$result){
	die("Could not create Table: ".mysql_error());
}
echo "Table created successfully!";
mysql_close($conn);
?>
</body>
</html>