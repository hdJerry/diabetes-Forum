<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Diabetes ChatBot</title>
    <link rel="icon" href="image/myspace.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/bootstrap.js"></script>
    <link rel="stylesheet" href="css/jquery-ui-1.10.3.custom.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/invent.css">

</head>
<body>
     <div class="container">
         <div class="row">
             <div class="col-md-6 col-md-offset-3 spectral">
                 <div class="row">
                     <div class="col-md-12 col-md-offset-0" id="body">

                     </div>
                 </div>
                     <div class="row">
                         <div class="col-md-6 col-md-offset-3 navbar-fixed-bottom fame">
                             <input type="text" class="form-control input-sm" id="input" value="" autofocus>
                         </div>
                 </div>
             </div>
         </div>
     </div>
<script src="js/invent.js"></script>
</body>
</html>