
<?php
if(isset($_POST["signup"])){
	// header("Location:index3.php");
	                            $username = $_POST['usernamesignup'];
								$email = $_POST['emailsignup'];
								$pass = $_POST['passwordsignup'];
								$passnew = $_POST['passwordsignup_confirm'];
								
								$sql = "SELECT *FROM signup WHERE username = '$username' OR email='$email'";
									$check = mysql_query($sql);
									if(!$check){
										die("could not get into database :".mysql_error());
									}else{
									while($row = mysql_fetch_assoc($check)){
										$dbusername = $row["username"];
										$dbemail = $row["email"];
										$dbpass = $row["password"];
									}
									if( $username===$dbusername){
											echo "Username Already Exist(:-";
												
										}elseif($email===$dbemail){
											echo "Email Already Exist";
											
										    }
										elseif($dbemail !== $email && $dbusername !== $username){
												$dbs = " INSERT INTO signup(username,email,password,re_password,signupdate)VALUES('$username','$email','$pass','$passnew',NOW())";
												$result = mysql_query($dbs);
												if(!$result){
													die("could not sign up: ".mysql_error());
												}
												echo "Registration Completed Thank you!(:";
												header("Location:index3.php#tologin");
												}
									}
						
		 }else if(isset($_POST["login"])){
				// header("Location:index3.php");
			        					
								$username = $_POST['username'];
								$pass = $_POST['password'];
											
								$sql = "SELECT username,password FROM signup WHERE username='$username' AND password='$pass'";
								mysql_select_db('POST');
									$check = mysql_query($sql);
									if(!$check){
										die("could not get into database :".mysql_error());
									}
									while($row = mysql_fetch_assoc($check)){
										$dbusername = $row["username"];	
										$dbpass = $row["password"];
										}

									if($dbusername === $username && $dbpass === $pass){
											header("Location:comment.php");
											
										}
												elseif($dbusername != $username || $dbpass != $pass ){
													header("Location:index3.php#toregister");
												echo "username or Password is Wrong!";
												echo "Please register if you have not registered!";
												
												}
		 }
		//  session_destroy();
?>