
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 1 && xhttp.status == 200) {
     document.getElementById("demo").innerHTML = xhttp.responseText;
     document.getElementById("comment").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "comment.php", true);
  xhttp.send();