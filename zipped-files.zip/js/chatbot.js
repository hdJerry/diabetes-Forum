var questionNum = 0;													// keep count of question, used for IF condition.
var question = `<h1>Welcome, I am Doctor Hogan.<br>
                   what is your name?</h1>`;				  // first question

var output = document.getElementById('output');
var user = document.getElementById('user');	// store id="output" in output variable
output.innerHTML = question;													// ouput first question
$("#user").hide();
function bot() {
    var input = document.getElementById("input").value;
    console.log(input);
        //user.innerHTML=input;
    var item = document.createElement("div");
    item.setAttribute("class","reply");
    user.appendChild(item);
    item.innerHTML=input;
    $(".reply").css({
        "backgroundColor":"white",
        "border":"1px solid grey",
        "borderRadius":"6px",
        "boxShadow":"2px 2px 20px 2px #808080",
        "padding":"10px 10px"
    });
    if (questionNum == 0) {
        $("#user").show();
        output.innerHTML = '<h1>hello ' + input + '</h1>';// output response
        document.getElementById("input").value = "";   		// clear text box
        question = '<h1>how old are you?</h1>';			    	// load next question
        setTimeout(timedQuestion, 1000);									// output next question after 2sec delay

    }

    else if (questionNum == 1) {
        output.innerHTML = '<h1>That means you were born in ' + (2016 - input) + '</h1>';
        document.getElementById("input").value = "";
        question = '<h1>where are you from?</h1>';
        setTimeout(timedQuestion, 1000);
    }

    else if (questionNum == 2) {
        output.innerHTML = '<h1>Am glad to have you here you are in good hands</h1>';
        document.getElementById("input").value = "";
        question = '<h1>Have you tested for diabetes?</h1>';
        setTimeout(timedQuestion, 1000);
    }
    else if(questionNum == 3){
        if(input=="yes"){
            output.innerHTML = '<h1>Its good to be aware of you status</h1>';
            document.getElementById("input").value = "";
            question = '<h1>No worries Hakunamatata. Do you have Diabetes ? </h1>';
            setTimeout(timedQuestion, 1000);
        }
        else if(input=="no"){
            output.innerHTML = '<h1>Its good to be aware of you status</h1>';
            document.getElementById("input").value = "";
            question = `<h1>
            Do you feel any of the following symptoms?
                <br>
        <ul>
            <li>Feeling very very thirsty</li>
            <li>Going to toilet often</li>
            <li>Losing weight even though you eat well</li>
            <li>Always feeling hungry</li>
            <li>Not seeing well</li>
            </ul>
        </h1>

        `;
            var change="justice";
            setTimeout(timedQuestion, 1000);
        }

    }
    else if (questionNum == 4) {
        if(question=='<h1>No worries Hakunamatata. Do you have Diabetes ? </h1>'){
            if(input=="yes"){
                output.innerHTML = '<h1>We are making progress</h1>';
                document.getElementById("input").value = "";
                question = '<h1>What type is it?</h1>';
                setTimeout(timedQuestion, 1000);
            }
            else if(input=="no"){
                output.innerHTML = '<h1>okay, ehmm ...</h1>';
                document.getElementById("input").value = "";
                question = `<h1>
                Do you feel any of the following symptoms?
            <br>
                <ul>
                <li>Feeling very very thirsty</li>
                <li>Going to toilet often</li>
                <li>Losing weight even though you eat well</li>
                <li>Always feeling hungry</li>
                <li>Not seeing well</li>
                </ul>
                </h1>
                 `;
               change="justice";
                setTimeout(timedQuestion, 1000);
            }

        }
        else if(change=="justice"){
            if(input=="yes"){
                output.innerHTML = '<h1>Well then you have nothing to worry about</h1>';
                document.getElementById("input").value = "";
                question = '<h1></h1>';
                setTimeout(timedQuestion, 1000);
            }
            else if(input=="no"){
                output.innerHTML = '<h1>WOW!!!</h1>';
                document.getElementById("input").value = "";
                question = '<h1>What will i do now with this one my God !!! ?</h1>';
                setTimeout(timedQuestion, 1000);
            }

        }

    }

}

function timedQuestion() {
    output.innerHTML = question;
}

//push enter key (using jquery), to run bot function.
$(document).keypress(function(e) {
    if (e.which == 13) {
        bot();																						// run bot function when enter key pressed
        questionNum++;																		// increase questionNum count by 1

    }
});

/**
 * Created by HD on 10/9/2017.
 */
