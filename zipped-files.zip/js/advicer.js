var questionNum=0;
var body=document.querySelector("#body");
var questions=[
    "Hello I am Dr Pat you can call me Pat, So may i know your name too?",
    "Have you tested for diabetes?",
    "Do you have Diabetes?",
    "What type?  options are Type i or Type ii and if you don't know say do not know",
    "Are you taking any diabetes medication?",
    "What type of medication? options are oral(tablet),insulin,or both",
    "Do you exercise?",
    "What type of exercise? options are running,walking,or both or others",
    "How often do you exercise? options are 3x a week,less than 3x a week or more than 3x a week",
    "Do you know about healthy eating?",
    "Do you have any of the following symptoms? Not seeing well,Always feeling hungry, Feeling very very thirsty, Going to toilet often, Losing weight even though you eat well, ",
    "Have you Seen the Doctor ",
    "Do you have other Symptoms",
    "How often do you eat high fiber such as rice,potato,maize meal or corn? options are daily,more than 3x a week,less than 3x a week",
    "How often do you eat low fat food such as meat,fish or skinless chicken? options are daily,more than 3x a week,less than 3x a week",
    "How often do you eat sugary and fatty food such as sweets,oily food,simple sugar? options are daily,more than 3x a week,less than 3x a week",
    "How often do you eat fruits and vegetable such as pea,apple,banana or mango? options are daily,more than 3x a week,less than 3x a week",
    "How many meal do you eat a day? options are one meal,two meals, three meals",
    "Do you monitor your sugar level?",
    "How often do you monitor your sugar level? options are 4 times a day,2 times a day,once a day,weekly",
    "What is your sugar level? options are less than 6, 6.69, greater than 7",
    "Do you smoke?",
    "Do you drink alcohol?"
];
var results=[];
var advices=[
    "Its important that you get a medication so as not to suffer further damages, so please take your drugs",
    "Exercise is key to a healthy living, the major problem in diabetes is that most people neglet the place of exercise and depend majorly on test",
    "Healthy eating plan is also key to healthy living,like they say 'Garbage in Garbage Out'",
    "Monitor your sugar level daily to checkmate the intensity of the diabetes",
    "I recommend that you visit the clinic as soon as possible so as to help you maintain a healthy living"
];
var question=questions[0];

var input = document.getElementById("input").value;

var out=document.createElement('div');
out.setAttribute('id','out');
//output.setAttribute('class','col-md-6');
body.appendChild(out);
out.innerHTML=question;




function bot(){
    var input = document.getElementById("input").value;
    console.log(input);
    var inputs=input.toLowerCase();
    var userDiv=document.createElement('div');
    userDiv.setAttribute("class","row");
    userDiv.setAttribute("id","userDiv");
    body.appendChild(userDiv);
    var user=document.createElement('div');
    user.setAttribute("class","col-md-4");
    user.setAttribute("id","user");

    userDiv.appendChild(user);
    user.innerHTML=inputs;
    results.push(inputs);
    var proPics=document.createElement('div');
    proPics.setAttribute("class","col-md-3");
    proPics.setAttribute("id","proPics");
    userDiv.appendChild(proPics);

    var advice=document.createElement("div");
    advice.setAttribute("class","advice");

    var output=document.createElement('div');
    output.setAttribute('class','output');





    if(questionNum==0){
        if(inputs!=""){
            body.appendChild(output);
            document.getElementById("input").value = "";
            question="hello "+inputs+", "+questions[1];
            output.innerHTML=question;
        }

    }else if(questionNum==1){
        if(inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni"){
            body.appendChild(output);
            document.getElementById("input").value = "";
            question = questions[2];
            output.innerHTML = question;
        }  else if (inputs=="no"||inputs=="nah"||inputs=="nope"||inputs=="rara"||inputs=="nooo"||inputs=="not at all"||inputs=="n"){
            document.getElementById("input").value = "";
            body.appendChild(output);
            question=questions[10];
            output.innerHTML=question;
        }
    }
    else if(questionNum==2){
        if(question==questions[2]){
            if(inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[3];
                output.innerHTML = question;
            }
            else if (inputs=="no"||inputs=="nah"||inputs=="nope"||inputs=="rara"||inputs=="nooo"||inputs=="not at all"||inputs=="n"){
                document.getElementById("input").value = "";
                body.appendChild(output);
                question=questions[10];
                output.innerHTML=question;
            }
        }else if(question==questions[10]){
            if(inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[11];
                output.innerHTML = question;
            }else if (inputs=="no"||inputs=="nah"||inputs=="nope"||inputs=="rara"||inputs=="nooo"||inputs=="not at all"||inputs=="n"){
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML=advices[1];
            }
        }

    }else if(questionNum==3){
        if(question==questions[3]){
            if (inputs == "type i" || inputs == "typei" || inputs == "type ii" || inputs == "typeii") {
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[4];
                output.innerHTML = question;
            }else if(inputs=="do not know"||inputs=="not sure"||inputs=="no idea"||inputs=="i am not sure"){
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML=advices[4];
                body.appendChild(output);
                question=questions[4];
                output.innerHTML=question;
            }
        }
    }else if(questionNum==4){
        if(question==questions[4]){
            if(inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[5];
                output.innerHTML = question;
            }else if (inputs=="no"||inputs=="nah"||inputs=="nope"||inputs=="rara"||inputs=="nooo"||inputs=="not at all"||inputs=="n"){
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML=advices[0];
                body.appendChild(output);
                question = questions[6];
                output.innerHTML = question;
            }
        }
    }
    else if(questionNum==5){
        if(question==questions[5]){
            if(inputs=="insulin"||inputs=="oral"||inputs=="both"){
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML=advices[0];
                body.appendChild(output);
                question = questions[6];
                output.innerHTML = question;
            }
        }
        else if(question==questions[6]){
            if(inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[7];
                output.innerHTML = question;
            }else if (inputs=="no"||inputs=="nah"||inputs=="nope"||inputs=="rara"||inputs=="nooo"||inputs=="not at all"||inputs=="n"){
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML=advices[1];
                body.appendChild(output);
                question = questions[9];
                output.innerHTML = question;
            }
        }
    } else if(questionNum==6) {
        if (question == questions[6]) {
            if (inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni") {
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[7];
                output.innerHTML = question;
            } else if (inputs == "no" || inputs == "nah" || inputs == "nope" || inputs == "rara" || inputs == "nooo" || inputs == "not at all" || inputs == "n") {
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML = advices[1];
                body.appendChild(output);
                question = questions[9];
                output.innerHTML = question;
            }
        }
        else if(question==questions[7]){
            if(inputs==="walking"||inputs==="running"||inputs==="both"||inputs==="others"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question=questions[8];
                output.innerHTML=question;
            }
        }else if(question==questions[9]){
            if (inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni") {
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[13];
                output.innerHTML = question;
            } else if (inputs == "no" || inputs == "nah" || inputs == "nope" || inputs == "rara" || inputs == "nooo" || inputs == "not at all" || inputs == "n") {
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML = advices[2];
            }
        }
    }else if(question==7){
        if(question==questions[8]){
            if (inputs==="3x a week"||inputs==="less than 3x a week"||inputs==="more than 3x a week"||inputs==="less"||inputs==="more"||inputs==="3x") {
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML = advices[2];
                body.appendChild(output);
                question = questions[13];
                output.innerHTML = question;
            }
        }else if(question==questions[13]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[14];
                output.innerHTML = question;
            }
        }
    }else if(questionNum==8){
        if(question==questions[13]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[14];
                output.innerHTML = question;
            }
        }else if(question==questions[14]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[15];
                output.innerHTML = question;
            }
        }
    }else if(questionNum==9){
        if(question==questions[14]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[15];
                output.innerHTML = question;
            }
        }else if(question==questions[15]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[16];
                output.innerHTML = question;
            }
        }
    }else if(questionNum==10){
        if(question==questions[15]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[16];
                output.innerHTML = question;
            }
        }else if(question==questions[16]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[17];
                output.innerHTML = question;
            }
        }
    }else if(questionNum==11){
        if(question==questions[16]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[17];
                output.innerHTML = question;
            }
        }else if(question==questions[17]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[18];
                output.innerHTML = question;
            }
        }
    }else if(questionNum==12){
        if(question==questions[17]){
            if (inputs=="daily"||inputs=="more than 3 times a week"||inputs=="less than 3 times a week"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[18];
                output.innerHTML = question;
            }
        }else if(question==questions[18]){
            if (inputs=="one meal"||inputs=="two meals"||inputs=="three meals"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[19];
                output.innerHTML = question;
            }
        }
    }else if(questionNum==13){
        if(question==questions[18]){
            if (inputs=="one meal"||inputs=="two meals"||inputs=="three meals"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[19];
                output.innerHTML = question;
            }
        }else if(question==questions[19]){
            if (inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[20];
                output.innerHTML = question;
            }else if(inputs=="no"||inputs=="nah"||inputs=="nope"||inputs=="rara"||inputs=="nooo"||inputs=="not at all"||inputs=="n"){
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML=advices[3];
            }
        }
    }else if(questionNum==14){
        if(question==questions[19]){
            if (inputs === "yes" || inputs === "yea" || inputs === "y" || inputs === "yep" || inputs === "beni"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[20];
                output.innerHTML = question;
            }else if(inputs=="no"||inputs=="nah"||inputs=="nope"||inputs=="rara"||inputs=="nooo"||inputs=="not at all"||inputs=="n"){
                document.getElementById("input").value = "";
                body.appendChild(advice);
                advice.innerHTML=advices[3];
            }
        }else if(question==questions[20]){
            if (inputs=="4 times a day"||inputs=="2 times a day"||inputs=="weekly"||inputs=="four times a day"||inputs=="two times a day"||inputs=="4x a day"||inputs=="2x a day"){
                body.appendChild(output);
                document.getElementById("input").value = "";
                question = questions[21];
                output.innerHTML = question;
            }
        }
    }
}


$(document).keypress(function(e) {
    if (e.which == 13) {

        bot();																						// run bot function when enter key pressed
        questionNum++;
    }

});/**
 * Created by HD on 10/16/2017.
 */
/**
 * Created by HD on 10/21/2017.
 */
