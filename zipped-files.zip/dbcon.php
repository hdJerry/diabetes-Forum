<?php
        $host="localhost";
        $user="root";
        $password="";
        $con = mysql_connect($host,$user,$password);
        if(!$con){
            die("Could not connect to server:".mysql_error());
        }
        else{
            echo"</br></br></br>";
        }
        mysql_select_db("POST");
?>