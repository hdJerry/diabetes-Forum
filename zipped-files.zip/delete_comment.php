<?php
$host="localhost";
$user="root";
$password="";
$con = mysql_connect($host,$user,$password);
if(!$con){
    die("Could not connect to server:".mysql_error());
}else{
    echo"</br></br></br></br>connecttion to server complete</br>";
}
mysql_select_db("POST");
$ids=$_GET['ids'];

mysql_query("delete from comments where comment_id='$ids'")or die(mysql_error());
header('location:admin.php#tologin');



?>