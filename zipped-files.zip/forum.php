<?php
    if(isset($_POST['send'])){
        // header('Location:forum.php');
        $host="localhost";
        $user="root";
        $password="";
        $con = mysql_connect($host,$user,$password);
        if(!$con){
            die("Could not connect to server:".mysql_error());
        }else{
            echo"</br></br></br></br>connecttion to server complete</br>";
        }

        $Post = $_POST['Post'];
          
          $sql = "SELECT *FROM posttab WHERE Post = '$Post'";
          mysql_select_db("FORUM");
          $check = mysql_query($sql,$con);

          if(!$check){
              die("</br></br></br></br>Could not Access the data in the table:".mysql_error());
          }
              while ($row = mysql_fetch_assoc($check)) {
                $dbPost = $row['Post'];
              }
          if($dbPost==$Post){
              echo'</br></br></br></br>Post Already Exist!!';
          }elseif ($dbPost != $Post) {
              $dbs = "INSERT INTO posttab(Post,submission_date) VALUES('$Post',NOW())";
          }
          $result = mysql_query($dbs);
          if(!$result){
              die("</br></br></br></br>Could not insert your Post:".mysql_error());
          }else{
              echo"</br></br></br></br>Post Inserted";
          }
          mysql_close($con);
    }
    
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Diabetes Forum</title>
    <link rel="icon" href="image/myspace.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/bootstrap.js"></script>
    <link rel="stylesheet" href="css/jquery-ui-1.10.3.custom.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/forum.css">

</head>
<body>

<div class = "navbar navbar-default navbar-fixed-top" >
    <div class="container">
        <div class="navbar-header">
            <a href="forum.html" class="navbar-brand">Diabetes Forum</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="
                   .navbar-collapse">
                <span class = "sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" >
            <ul class="nav navbar-nav">
                <li class="active" ><a href="#">Home</a> </li>
                <li ><a href="#">About</a> </li>
                <li ><a href="#">Download App</a> </li>

            </ul>
        </div>
    </div>
</div>

<!--Forum Part-->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
               <div class="row">
                   <!--Discussion section-->
                 <div class="col-md-8 discuss">
                     
                        <div class="row">
                            <div class="col-md-10 formBack col-md-offset-1">
                                <form class="form-group" method = "post" action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                                    <textarea cols="10" rows="6" class="form-control" name="Post" id="post" placeholder="Share you thoughts"></textarea>
                                    <input type="submit" name="send" class="btn btn-success" value="POST">
                                </form>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-10 col-md-offset-1 posts">
                                <?php
                                $host="localhost";
                                 $user="root";
                                 $password="";     
                                $con = mysql_connect($host,$user,$password);
                                if(!$con){
                                    die("Could not connect to server:".mysql_error());
                                }
                                mysql_select_db("FORUM");
                                $sql = "SELECT *FROM posttab ORDER BY Post_Id DESC";
                                $values=mysql_query($sql,$con);
                                if(!$values){
                                    die("Could not retrieve data:".mysql_error());
                                }
                                while($row = mysql_fetch_array($values,MYSQL_ASSOC)){
                                    echo"<div class='row'>
                                    <div class='col-md-12' id='posted'>
                                      {$row['Post']}
                                    <div class='row'>
                                      <div class='col-md-12'>
                                    
                                      <span class='glyphicon glyphicon-comment'></span>
                                      <span id='state' class='hides'>Comment</span>
                                 <div class='row'>
                                     <div class='col-md-10 formBack col-md-offset-1' id='responds'>
                                      <form class='form-group' method='post'>
                                        <textarea cols='10' rows='6' class='form-control' name='Post' id='respond' placeholder='Share you thoughts'></textarea>
                                          <input type='submit' name='send' class='btn btn-success' value='SEND'>
                                           </form>
                                             </div>
                                           </div>
                                         </div>
                                        </div>
                                      </div>
                                    </div>";
                                }
                            
                                 mysql_close($con);
                                ?>
                            </div>
                        </div>
                    </div><!--Discussion section ends-->

                   <!--Recent health Tips-->
                   <div class="col-md-4 recent">
                      <h2>Help ooh!!!</h2>
                   </div> <!--Recent health tips ends-->

                </div>
        </div>
    </div>
</div>

<script src="js/forum.js"></script>
</body>
</html>