<?php
include('dbcon.php');
?>

<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>DashBoard</title>
    <link rel="icon" href="image/bot1.png" type="image/x-icon"/>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/jquery.lazy.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/angular.min.js"></script>
    <link rel="stylesheet" href="css/jquery-ui-1.10.3.custom.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="screen">
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
</head>
<style>
   .link{
        border: 1px solid grey;
            margin-left: -15px;
          padding-top: 30px;
          padding-bottom: 30px;
         background-color: grey;
       font-family: Georgia;
       position: fixed;
       height: 100%;
         }
   body{
       background:white url(images/eye.jpg) repeat top left;
   }
   #register,
   #login{
       position: absolute;
       top: 0;
       width: 100%;
       padding: 18px 6% 60px 6%;
       margin-top:20px;
       background: rgb(247, 247, 247);
       border: 1px solid rgba(147, 184, 189,0.8);
       -webkit-box-shadow: 0pt 2px 5px rgba(105, 108, 109,  0.7),	0px 0px 8px 5px rgba(208, 223, 226, 0.4) inset;
       -moz-box-shadow: 0pt 2px 5px rgba(105, 108, 109,  0.7),	0px 0px 8px 5px rgba(208, 223, 226, 0.4) inset;
       box-shadow: 0pt 2px 5px rgba(105, 108, 109,  0.7),	0px 0px 8px 5px rgba(208, 223, 226, 0.4) inset;
       -webkit-box-shadow: 5px;
       -moz-border-radius: 5px;
       border-radius: 5px;
   }
    a:hover{
        background-color:transparent!important;
        color: green;
    }
    #reg{
        border-bottom: 1px solid grey;
    } .born{
          color:dodgerblue;
          font-size:0.8em;
          text-shadow:2px 1px 2px grey,4px 3px 2px green;
          /*margin:10px 0 0 50px;*/
          margin-right:30px;
          font-family:georgia;
          padding-top:10px;
      }
   .born:hover{
       color:white;
       text-decoration: none;
   }
   .topspec{
       background:black;
       /*margin-top:-60px;*/
       height:50px;
   }
    .solve{
        margin-top: -13px;
    }section{
       margin-left: 15px;
         }
    .adm{
        color: white;
        margin: 10px;
        font-family: roboto;
        font-size: 1.3em;
    }ul{
       padding: 20px;
       font-size: 1.0em;
             font-family:georgia;
         }
         .dash{
             margin-top: 10px;

         }.glyphicon-dashboard{
             color: white;
             margin-right: 5px;
                   }
</style>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 topspec navbar-fixed-top">
            <p  class="navbar-left adm"><span class="glyphicon glyphicon-tree-deciduous "></span>Admin</p>
          
        </div>
    </div>
<div class="container-fluid">
    <div class="row solve">
        <div class="col-md-2 link">
		       <span class="glyphicon glyphicon-dashboard "></span><a href="admin.php" class="born">DASH BOARD</a>
            <ul class="">
                <li><span class="glyphicon glyphicon-equalizer"></span><a href="#toregister" class="to_register" id="reg">Posts</a></li>
                <li><span class="glyphicon glyphicon-equalizer"></span><a href="#tologin" class="to_register"> Comments </a></li>
            </ul>
        </div>
        <section>
            <div id="container_demo" >
           

                <!--<?php
                $have = "select * from comments";
                $querys=mysql_query($have)or die(mysql_error());
                while($roww=mysql_fetch_array($querys)) {
                    $ids = $roww['comment_id'];
                    ?>

                    <?php
                }
                ?>-->
                <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                <a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                    <div id="login" class="animate col-md-10">
                        <table class='table table-hover table-bordered'>
                            <tr>
                                <th class="specnum">S/N</th>
                                <th class="spec">Comments</th>
                                <th>Username</th>
                                <th>Remove</th>
                            </tr>
                            <?php

                            $choice="SELECT *FROM comments";
                            $count=1; 
                            $valid=mysql_query($choice);
                            while($val=mysql_fetch_assoc($valid)){
                                $ids = $val['comment_id'];
                                ?>
                                <tr>
                                    <td class="specnum"><?php echo $count++;?></td>
                                    <td class="spec"><?php echo $val['content']; ?></td>
                                    <td><?php echo $val['username'] ;?></td>
                                    <td width="40"><a class="btn btn-danger" href="delete_comment.php<?php echo '?ids='.$ids; ?>"><i class="glyphicon glyphicon-trash"></i></a></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                         <!--<?php
                $hve = "select * from posts";
                $query=mysql_query($hve)or die(mysql_error());
                while($row=mysql_fetch_array($query)) {
                    $id = $row['post_id'];
                    ?>

                    <?php
                }
                ?>-->

                    <div id="register" class="animate col-md-7">
                        <table class='table table-hover table-bordered'>
                            <tr>
                                <th class="specnum">S/N</th>
                                <th class="spec">Posts</th>
                                <th>Username</th>
                                <th>Remove</th>
                            </tr>
                            <?php

                            $choice="SELECT *FROM posts";
                            $count=1;
                            $valid=mysql_query($choice);
                            while($val=mysql_fetch_assoc($valid)){
                                $id = $val['post_id'];
                                ?>
                                <tr>
                                    <td class="specnum"><?php echo $count++;?></td>
                                    <td class="spec"><?php echo $val['content']; ?></td>
                                    <td><?php echo $val['username'] ;?></td>
                                    <td width="40"><a class="btn btn-danger" href="delete_post.php<?php echo '?id='.$id; ?>"><i class="icon-trash"></i></a></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>

                </div>
            </div>
        </section>
    </div>
</div>

</div>
</body>
</html>