<?php
session_start();
?>
<?php
include('dbcon.php');
include('dblog.php');

$username=$_POST["username"];
$_SESSION['used']=$username;
?>
<?php
  if(isset($_POST['change'])){
          $email=$_POST['email'];
          $password=$_POST['password'];
          $re_password=$_POST['re_password'];

          if($password===$re_password){
              $cpass="UPDATE signup SET password='$password' WHERE email='$email'";
              $confirm=mysql_query($cpass);
              if(!$confirm){
                  die("Could not change pass word:".mysql_error());
              }else{
                  echo "Password Changed";
                  echo "<script type='text/javascript'>alert('Password Changed')</script>";
              }
          }else{
              echo "Passwords are Not the same";
                  echo "<script type='text/javascript'>alert('Passwords are not the same')</script>";
          }
  }
?>

<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        
        <title>Login and Registration Form</title>
        <link rel="icon" href="image/bot1.png" type="image/x-icon"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
          <script src="js/jquery-3.1.0.min.js"></script>
	 <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
        <!--<link rel="shortcut icon" href="../favicon.ico"> -->
         
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style2.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
        <link rel="stylesheet" href="css/bootstrap.css">

        <!--<script>
function showHint(str) {
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET", "dbcon.php?q=" + str, true);
        xmlhttp.send();
    }
}
</script>-->

        <style type="text/css">
        .change_link{
            padding:20px!important;
        }
        body{
            position:fixed!important;
        }
        header{
            margin-top:-95px!important;
        }
        section{
            margin-top:-30px!important;
            margin-left:70px!important;
        }
        .modalheader{
            color:grey;
        }.modal-content{
          background: url(images/bg.jpg) repeat top left;    
              }
        </style>
    </head>
    <body>
    
        <div class="container">
            <header>
                <h1>Login and Registration Form</h1>
<!--                
        <p><b>Start typing a name in the input field below:</b></p>
<form> 
First name: <input type="text" onkeyup="showHint(this.value)">
</form>
<p>Suggestions: <span id="txtHint"></span></p>-->

            </header>
            <section>
            <div class="row">
               <div class="col-md-12">
                <div id="container_demo">
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper" >
                        <div id="login" class="animate form">
                            <form  method="POST"  action="index3.php">
                                <h1>Log in</h1>
                                <p>
                                    <label for="username" class="uname" data-icon="u" > Your username </label>
                                    <input id="username" name="username" required="required" type="text" placeholder="myusername"/>
                                </p>
                                <p>
                                    <label for="password" class="youpasswd" data-icon="p"> Your password </label>
                                    <input id="password" name="password" required="required" type="password" placeholder="eg. X8df!90EO" />
                                </p>
                                <p class="keeplogin">
									<input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" />
									<label for="loginkeeping">Keep me logged in</label>
								</p>
                                <p class="login button">
                                    <input type="submit" value="Login" name="login"/>
								</p>
                                <p class="change_link">
                                   <a href="#myModal4" data-toggle="modal">forgotten password</a>
									Not a member yet ?
									<a href="#toregister" class="to_register">Join us</a>
								</p>
                            </form>
                        </div>

                        <div id="register" class="animate form">
                            <form  method="POST">
                                <h1> Sign up </h1>
                                <p>
                                    <label for="usernamesignup" class="uname" data-icon="u">Your username</label>
                                    <input id="usernamesignup" name="usernamesignup" required="required" type="text" placeholder="mysuperusername690" />
                                </p>
                                <p>
                                    <label for="emailsignup" class="youmail" data-icon="e" > Your email</label>
                                    <input id="emailsignup" name="emailsignup" required="required" type="email" placeholder="mysupermail@mail.com"/>
                                </p>
                                <p>
                                    <label for="passwordsignup" class="youpasswd" data-icon="p">Your password </label>
                                    <input id="passwordsignup" name="passwordsignup" required="required" type="password" placeholder="eg. X8df!90EO"/>
                                </p>
                                <p>
                                    <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Please confirm your password </label>
                                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="eg. X8df!90EO"/>
                                </p>
                                <p class="signin button">
									<input type="submit" value="Sign up" name="signup"/>
								</p>
                                <p class="change_link">
									Already a member ?
									<a href="#tologin" class="to_register"> Go and log in </a>
								</p>
                            </form>
                        </div>

                    </div>
                 </div>
                </div>
               </div> 
            </section>

             <div class="modal fade modal-lg" id="myModal4" role="dialog">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h3 class="modalheader">Change Password</h3>
                      </div>
                      <div class="modal-body">
                       <form method="post" action="index3.php#tologin" class="form">
                           <div class="form-group">
                               <input type="text" name="email" placeholder="email" class="form-control" required>
                           </div>
                           <div class="form-group">
                               <input type="password" name="password" placeholder="new password" class="form-control" required>
                           </div>
                           <div class="form-group">
                               <input type="password" name="re_password" placeholder="re-enter new password" class="form-control" required>
                           </div>
                           <br/>
                       <input type='submit' name='change' class="btn btn-primary" value="Change Password">
                       </form>
                      </div>
                      <!--<div class="modal-footer">
                          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                      </div>-->
                      
                  </div>
              </div>
          </div>

     
    </body>
</html>