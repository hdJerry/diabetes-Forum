 <?php
 session_start();
 ?>
<?php
include('dbcon.php');
?>

<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Diabetes Forum</title>
     <link rel="icon" href="image/bot1.png" type="image/x-icon"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-3.1.0.min.js"></script>
	 <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.lazy.js"></script> 
     <script src="js/myAjax.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/angular.min.js"></script>
<!--<link href="https://api.motion.ai/sdk/webchat.css" rel="stylesheet" type="text/css">
<script src="https://api.motion.ai/sdk/webchat.js"></script>
<script>
   motionAI_Init('77923?color=2898EA&sendBtn=SEND&inputBox=Type%20something...&token=7891de067e36e69528fc41a9ef080ca4',true,435,436,'https://i.imgur.com/F6ty6mU.png');
   /* You may also invoke motionAI_Open() to manually open the modal. */
</script>-->`
<script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=43829921"></script>
    <link rel="stylesheet" href="css/jquery-ui-1.10.3.custom.css">
    <link rel="stylesheet" href="css/bootstrap.css">
     <link rel="stylesheet" href="css/comment2.css">
    <!--<link rel="stylesheet" href="css/comment.css">-->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="screen">


  <style>
   /*@import "css/comment2.css";
   .drop{
  margin-top:15px;
  font-size:1.3em;
  float:left;
}#bmi{
    display:none;
}.down:hover{
     text-shadow:1px 1px 1px midnightblue,1px 2px 2px mediumblue;
         background-color:none!important;
}.navbar-toggle:hover{
    background-color:rgb(87, 184, 255)!important;
    border-color:rgb(87, 184, 255)!important;
}
.navbar-toggle{
    border-color:rgb(87, 184, 255)!important;
}.probody{
    border-radius:50px;
    width:40px;
    height:40px;
    /*border:1px solid red;
    float:left;
    margin-top:-10px;
}
.loglink{
    margin-top:5px;
}.realpro{
    width:100%;
    height:100%;
    border-radius:100%;
}.named{
    color:#fff;
    font-style:italic;
    padding-left:5px;
    padding-right:5px;
}*/
div,a,table{
      /*color:black;*/
      word-wrap:break-word;
  }
  </style>
</head>
<body>
    <div class="container-fluid">
    <header>
        <div class="row">

            <div class="col-md-12 topspec navbar-fixed-top">
                <a href="comment.php" class="born navbar-right">Diabetes Forum</a>
                </div>
             </div>
<div class = "navbar navbar-inverse navbar-fixed-top" >
 
    <div class="container">
   
        <div class="navbar-header">
      <p  class="drop"><a href="#" class="down">
        <span class="glyphicon glyphicon-arrow-down"></span>
        BMI
        </a></p>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="
                   .navbar-collapse">
                <span class = "sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" >
            <ul class="nav navbar-nav">
                <li><a href="comment.php" class="navigate"><span class="glyphicon glyphicon-home"></span>Home</a> </li>
                <li ><a href="https://api.motion.ai/webchat/77923?color=2898EA&sendBtn=SEND&inputBox=Type%20something...&token=7891de067e36e69528fc41a9ef080ca4" class="navigate"><span class="glyphicon glyphicon-headphones"></span>Diabetes Check</a> </li>
                <li ><a href="#" class="navigate"><span class="glyphicon glyphicon-earphone"></span>Contact Us</a> </li>
            </ul>
            <div class="navbar-right loglink">
            <p class="username"><div class="probody"><img src="image/jay.jpg" class="realpro"></div>
               <span class="named">
                <?php
                  $uservalue=$_SESSION['used'];
                  echo $uservalue;
                  if($uservalue == ""){
                      header("Location:mariopage.html");
                  }
                ?>
                </span>
                <a href="logout.php" class="logname">Log Out<span class="glyphicon glyphicon-log-out"></span></a>
                </p>
        
          
           </div>
        </div>
        
        
    </div>
</div>
</header>

  <div class="container-fluid">
      <div class="row fixit" >
          <div class="modal fade modal-lg" id="myModal" role="dialog">
                     <div class="modal-dialog">
                         <div class="modal-content">
                              <div class="modal-header">
                               <button type="button" class="close" data-dismiss="modal">&times;</button>
                               <h3 class="modalheader">BMI TABLE</h3>
                              </div>
                            <div class="modal-body">
  <table class="table table-responsive table-striped table-hover table-condensed">
  <thead>
      <tr>
       <th>Range</th>
       <th>Meanings</th>
       <th>Advices</th>
    </tr>
 </thead>
     <tbody>
<tr>
 <td>
  30 and Above
  </td>
<td>
  Obese
 </td>
 <td>
Reduce your fat intake and do a lot of exercise
</td>
    </tr>
        <tr>
         <td>
		 25 to 30
		</td>
            <td>
			 Overweight
			 </td>
             <td> 
			 Overweight diabetic patients should limit caloric intake until target weight is achieved.
			 In persons with type 2 diabetes this usually results in marked improvement and may eliminate
			the need for drugs such as oral hypoglycemic agents.
			 </td>
         </tr>
<tr>
  <td>
 18.5 to 25
 </td>
     <td>
 Normal
 </td>
     <td>
 Pray
	 </td>
 </tr>
      <tr>
 <td>
	less than 18.5
</td>
     <td>
		 Underweight
	 </td>
 <td>
	 Pray
 </td>
  </tr>
    </tbody>
</table>
        </div>
             <div class="modal-footer">
                 <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    </div>  
                         </div>
                           </div>
                              </div>

          <div class="modal fade modal-lg" id="myModal2" role="dialog">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h3 class="modalheader">BMI CHART</h3>
                      </div>
                      <div class="modal-body">
                        <img src="images/Capture.PNG" style="width: 100%;"/>
                      </div>
                      <div class="modal-footer">
                          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                      </div>
                  </div>
              </div>
          </div>

     <div class="col-md-3 bmicalc" ng-app="myApp" ng-controller="myEnjoy" id="bmi">
         <div class="row">
           <div class="col-md-12">
              <h4><a href="#" data-toggle="tooltip" data-placement="right" title="Body Mass Index">BMI</a> Calculation</h4>
                      <form class="form">
                         <div class="form-group">
                           <input type="text" ng-model="weight" id="weight" class="form-control" placeholder="weight in kg" required>
                        </div>
               <div class="form-group">
        <input type="text" ng-model="height" id="height" class="form-control" placeholder="height in meters eg 1.75" required>
             </div>
    </form>
<p>Weight: {{weight}}</p>
<p>Height: {{height}}</p>
<p><span class="usedX">@<?php echo $_SESSION['used'];?></span> below is your <a href="#" data-toggle="tooltip" data-placement="right" title="Body Mass Index">BMI</a> result </p>
<p>BMI = {{result()}} kg/m<sup>2</sup></p>
    </div>
         </div>
                 <!--<p id="mark"></p>-->
     <div class="contaner-fluid">
         <a data-toggle="modal" href="#myModal" >BMI table Check</a><br/>
              <a data-toggle="modal" href="#myModal2" >BMI Chart</a>
                   </div>
                         </div>
           <div class="col-md-7 postcom col-md-offset-4" >
                <div class="row">
                    <div class="col-md-10 formback">
                        <form method="POST" class="form-group">
                               <textarea rows="5" name="post_content" class="span6 form-control" placeholder="What's on Your Mind" autofocus required></textarea>
                               <br/>
                               <button name="posts" type="submit" class="btn btn-success"><i class="icon-share"></i>&nbsp;Post</button>
                           </form>
   <?php
if(isset($_POST['posts'])){
        //  header('location:comment.php');
		$post_content=$_POST['post_content'];
        $username=$_SESSION['used'];
        $dbPost="";
        $row="";

        if($post_content!==""){
          
          $sql = "SELECT content FROM posts WHERE content='$post_content'";
         
          $check = mysql_query($sql);

          if(!$check){
           die("</br>Could Not retrieve data:".mysql_error());
          }else{
            while ($row = mysql_fetch_assoc($check)) {
                $dbPost = $row['content'];
                           
              }
                if($dbPost===$post_content){
              die("</br><script type='text/javascript'>alert('Post Already Exist')</script>:".mysql_error());
                 }elseif ($dbPost !== $post_content) {  
              $db="INSERT INTO posts (content,username) VALUES('$post_content','$username')";
              
                  }
                   $result = mysql_query($db);
             if(!$result){
              die("</br>Could not insert your Post:".mysql_error());
             }else{
              echo"</br><script type='text/javascript'>alert('Post successful')</script>";
             
               }
          }

        }else{
            echo"</br><script type='text/javascript'>alert('Post must contain valid words!')</script>";
        }
		
		}
		?>
                      </div>
                       <div class="row">
                          <div class="col-md-10 lazy" data-loader="ajax" data-src"comment.php" data-method="post" data-type="php">
			<?php
            $hve = "select * from posts order by post_id DESC";
	$query=mysql_query($hve)or die(mysql_error());
	while($row=mysql_fetch_array($query)){
	$id=$row['post_id'];
    $idlop=$row['post_id'];
    $posted = $row['content'];
          $userverify = $row['username'];
	?>
	
	
	
	
    <div class="row">
      <div class="col-md-11 comm">
      <h5>Post by <?php echo $userverify; ?></h5>
           <div class="alert alert-info" id="demo"><?php echo $row['content']; ?>
           <?php
              $cmm=mysql_query("select * from posts WHERE post_id='$id'")or die(mysql_error());
	while($cmm_row=mysql_fetch_array($cmm)){
         $ide = $cmm_row['post_id'];
         $postedit = $cmm_row['content'];
        ?>
              <p>
           <?php
           if($_SESSION['used']===$userverify){?>
              <br/>
              <a href="#<?php echo $ide; ?>" data-target="#idlop" data-toggle="modal" style="color:red;"><span class="glyphicon glyphicon-pencil"></span>Edit</a>
              <?php
 if(isset($_POST['repost'])){
            header("Location:comment.php");
            $newpost = $_POST['newpost'];
            $newpostid = $_POST['deal'];
               $ed = "UPDATE posts SET content='$newpost' WHERE post_id = $newpostid";
                $eval=mysql_query($ed);

            if(!$eval){
                die("could not edit comment".mysql_error());
            }
            // else{
            //     echo "comment edited";
            // }
          }
           }
           ?>
           </p>
           <div class="modal fade modal-lg" id="idlop" role="dialog">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                      <h4>Edit current Post</h4>
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modalheader">Edit current Post</h4>
                      </div>
                      <div class="modal-body">
     <form  method="POST" role="form" class="form-group">
         <input type="hidden" name="deal" value="<?php echo $ide; ?>">
             <textarea rows="5" name="newpost" class="span7 form-control" placeholder="Your Comment Here" required><?php echo $postedit; ?></textarea>
                            <br/>
             <button name="repost" type="submit" class="btn btn-info"><i class="icon-share"></i>&nbsp;REPOST</button>
         </form>
                        
                      </div>
                    </div>
               </div>
            </div>
             <?php
                  }
               ?>
     
         
           </div>
        <div >
           <?php 
	$comment_query=mysql_query("select * from comments where post_id='$id'")or die(mysql_error());
	$count=mysql_num_rows($comment_query);
	?>
 <a href="#<?php echo $ide; ?>" data-toggle="modal" data-backdrop="static" class="replyer"><i class="icon-comments-alt"></i>&nbsp;<span class="badge badge-info"><?php echo $count; ?></span>Comment</a><br/><br/>
               

           </div>
        <div class="row">
             <div class="col-md-12 col-md-offset-0 rep">
        <!--<h5 class="responses"><span class="glyphicon glyphicon-comment"></span>Comments...</h5>-->
    <?php $comment=mysql_query("select * from comments WHERE post_id='$id'")or die(mysql_error());
	while($comment_row=mysql_fetch_array($comment)){
            $idedit = $comment_row['comment_id'];
         $contentedit = $comment_row['content'];
            $user = $comment_row['username'];
        ?>
       
	<div id="comment"><h5 class="comuser"><?php  echo $comment_row['username'];?>'s&nbsp;comment </h5><?php echo $comment_row['content'];?>
	<p><?php
    if($_SESSION['used']==$user){?>
        <a href="#<?php echo $idedit; ?>" data-toggle="modal"><span class="glyphicon glyphicon-pencil" style="color:black;"></span>Edit</a>
 <?php
     if(isset($_POST['edit'])){
        header("Location:comment.php");
              $newcontent = $_POST['newcomment'];
            $ideditor = $_POST['idle'];
               $ed = "UPDATE comments SET content='$newcontent' WHERE comment_id = $ideditor";
                $eval=mysql_query($ed);
            if(!$eval){
                die("could not edit comment".mysql_error());
            }
            // else{
            //     echo "comment edited";
            // }
          }

    }
          ?>

 
          <div class="modal fade modal-lg" id="<?php echo $idedit; ?>" role="dialog">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h3 class="modalheader">Edit your comment</h3>
                      </div>
                      <div class="modal-body">
                      <form  method="POST" role="form" class="form-group">
                            <input type="hidden" name="idle" value="<?php echo $idedit; ?>">
                            <textarea rows="5" name="newcomment" class="span7 form-control" placeholder="Your Comment Here" required><?php echo $contentedit; ?></textarea>
                            <br>
                            <button name="edit" type="submit" class="btn btn-primary"><i class="icon-share"></i>&nbsp;update</button>
                            </form>
                        
                      </div>
                    </div>
              </div>
          </div>
   
	   </p>
    </div>
    
	
	<?php } ?>
           


             </div>
           </div>
       </div>

    </div>
	
	    <!-- Modal -->
 <div id="<?php echo $ide;?>"  class="modal fade modal-md col-md-offset-0" role="dialog" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
           <div class="modal-header">
          </div>
          <div class="modal-body ">
	
	<!--comment -->
 <form  method="POST" role="form" class="form-group">
	<input type="hidden" name="id" value="<?php echo $id; ?>">
         <textarea rows="5" name="comment_content" class="span7 form-control" placeholder="Your Comment Here" required></textarea>
	        <br/>
            <button name="comments" type="submit" class="btn btn-info"><i class="icon-share"></i>&nbsp;Comment</button>
   </form>
	<br>
	<!--- end comment -->
        </div>
           <div class="modal-footer">
             <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
   
            </div>
          </div>
       </div>
	</div>

	<?php  } ?>
    
                            </div>
                       </div>
                 </div>
                 
              </div>
           
         </div>
         <!--<div class="row">
            <div class="col-md-12 footer navbar-fixed-bottom">
              <div class="container">
              <div class="row">
              <div class="col-md-7">
                 <h5 class="footername">Diabetes Forum</h5>
                     </div>
                     <div class="col-md-5">
                         <ul class="navbar-nav footerlist">
                     <li><a href="comment.php" class="navigate">Home</a> </li>
                      <li ><a href="invent.html" class="navigate">Diabetes Check</a> </li>
                         <li ><a href="#" class="navigate">Contact Us</a> </li>
                         </ul>
                     </div>
                   </div>
              </div>
            </div>
    </div>-->
	
         
      </div>

		
	<?php
		if(isset($_POST['comments'])){
            header('location:comment.php');
		$comment_content=$_POST['comment_content'];
         $username=$_SESSION['used'];
		$post_id=$_POST['id'];
		$dbs = "insert into comments (content,username,post_id) values('$comment_content','$username',$post_id)";
		mysql_query($dbs)or die(mysql_error());	
		}
		?>

 <script type="text/javascript">
		$(".formback,.comm,.born,img,#modal-wrap").draggable();
        $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
    $(".down").click(function(){
        $("#bmi").fadeToggle("slow");
    });
});
        var app=angular.module("myApp",[]);
        app.controller("myEnjoy",function($scope){
                $scope.weight;
                $scope.height;
             $scope.result=function(){
              return ($scope.weight/($scope.height*$scope.height)).toFixed(2);
             }
        });

        </script>   
</body>
</html>